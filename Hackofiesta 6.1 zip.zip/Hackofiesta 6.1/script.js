
  const tabs = document.querySelectorAll('.spread-tabs .tab');
  const contents = document.querySelectorAll('.tab-content');

  tabs.forEach(tab => {
    tab.addEventListener('click', () => {
      // Remove active class from all tabs
      tabs.forEach(t => t.classList.remove('active'));
      // Add active class to the clicked tab
      tab.classList.add('active');

      // Hide all tab contents
      contents.forEach(content => content.classList.remove('active'));

      // Show only the selected tab content
      const target = tab.getAttribute('data-tab');
      const activeTab = document.getElementById(target);
      if (activeTab) {
        activeTab.classList.add('active');
      }
    });
  });
  document.addEventListener("DOMContentLoaded", () => {
    const elements = document.querySelectorAll(".animate-on-scroll");
    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          entry.target.classList.add("animate");
        }
      });
    }, { threshold: 0.2 });

    elements.forEach(el => observer.observe(el));
  });
  document.addEventListener("DOMContentLoaded", function(){
    const observerOptions = { threshold: 0.5 };
    const observer = new IntersectionObserver((entries, observer) => {
      entries.forEach(entry => {
        if(entry.isIntersecting){
          entry.target.classList.add('animate');
          observer.unobserve(entry.target);
        }
      });
    }, observerOptions);
    
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
      observer.observe(el);
    });
  });
  const mindblock = document.getElementsByClassName('mindblock');

mindblock.forEach((block) => {
  block.addEventListener('click', () => {
    block.style.color = '#6a5acd'; // Set text color
  });
});

