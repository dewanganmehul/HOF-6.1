import { ethers } from "ethers";
import * as dotenv from "dotenv";
dotenv.config();
import contractABI from "./contractabi.json" assert { type: "json" };

// Replace with your provider URL
const provider = new ethers.JsonRpcProvider("https://eth-sepolia.g.alchemy.com/v2/8M-A8S59VNodqtUAIom94hhtunRlqYHF");

// Securely use wallet private key
const wallet = new ethers.Wallet(process.env.PRIVATE_KEY, provider);

// Replace with your deployed contract address
const contractAddress = "0xf6Bb8b2803E63f2d7165B95013A03b30Da71c14D";
const contract = new ethers.Contract(contractAddress, contractABI.abi, wallet);

async function main() {
    try {
        const blockNumber = await provider.getBlockNumber();
        console.log("Current Block Number:", blockNumber);

        const balance = await provider.getBalance(wallet.address);
        console.log("Wallet Balance:", ethers.formatEther(balance), "ETH");

        const nonce = await provider.getTransactionCount(wallet.address);
        console.log("Transaction Count (Nonce):", nonce);

        const tx = await contract.set(42); // Example write
        await tx.wait();
        console.log("Transaction confirmed:", tx.hash);

        const value = await contract.value();
        console.log("Stored Value:", value.toString());

        const gasEstimate = await contract.set.estimateGas(42);
        console.log("Gas Estimate for set():", gasEstimate.toString());

    } catch (error) {
        console.error("Error:", error);
    }
}
main();
