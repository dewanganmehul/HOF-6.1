// app.js
let provider, signer, contract;
let userAddress;

// Contract Configuration (Update these!)
const contractAddress = "0xd9145CCE52D386f254917e481eB44e9943F39138";
const contractABI = [
	{
		"inputs": [
			{
				"internalType": "address",
				"name": "_fromToken",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "_toToken",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "_rate",
				"type": "uint256"
			}
		],
		"name": "createOffer",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "offerId",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "fromToken",
				"type": "address"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "toToken",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "rate",
				"type": "uint256"
			}
		],
		"name": "OfferCreated",
		"type": "event"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "offerId",
				"type": "uint256"
			},
			{
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "swapTokens",
		"outputs": [],
		"stateMutability": "nonpayable",
		"type": "function"
	},
	{
		"anonymous": false,
		"inputs": [
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "offerId",
				"type": "uint256"
			},
			{
				"indexed": true,
				"internalType": "address",
				"name": "buyer",
				"type": "address"
			},
			{
				"indexed": false,
				"internalType": "uint256",
				"name": "amount",
				"type": "uint256"
			}
		],
		"name": "TokensSwapped",
		"type": "event"
	},
	{
		"inputs": [],
		"name": "getAllOffers",
		"outputs": [
			{
				"components": [
					{
						"internalType": "address",
						"name": "fromToken",
						"type": "address"
					},
					{
						"internalType": "address",
						"name": "toToken",
						"type": "address"
					},
					{
						"internalType": "uint256",
						"name": "exchangeRate",
						"type": "uint256"
					},
					{
						"internalType": "address",
						"name": "owner",
						"type": "address"
					}
				],
				"internalType": "struct GameCurrencyExchange.ExchangeOffer[]",
				"name": "",
				"type": "tuple[]"
			}
		],
		"stateMutability": "view",
		"type": "function"
	},
	{
		"inputs": [
			{
				"internalType": "uint256",
				"name": "",
				"type": "uint256"
			}
		],
		"name": "offers",
		"outputs": [
			{
				"internalType": "address",
				"name": "fromToken",
				"type": "address"
			},
			{
				"internalType": "address",
				"name": "toToken",
				"type": "address"
			},
			{
				"internalType": "uint256",
				"name": "exchangeRate",
				"type": "uint256"
			},
			{
				"internalType": "address",
				"name": "owner",
				"type": "address"
			}
		],
		"stateMutability": "view",
		"type": "function"
	}
] ;

// HTML Elements
const connectBtn = document.getElementById('connectWallet');
const createOfferBtn = document.getElementById('createOfferBtn');
const offersList = document.getElementById('offersList');

// Initialize Contract
async function initContract() {
  provider = new ethers.providers.Web3Provider(window.ethereum);
  signer = provider.getSigner();
  contract = new ethers.Contract(contractAddress, contractABI, signer);
}

// 1. Connect Wallet
connectBtn.addEventListener('click', async () => {
  try {
    if (!window.ethereum) throw new Error("Install MetaMask!");
    
    await window.ethereum.request({ method: 'eth_requestAccounts' });
    await initContract();
    
    userAddress = await signer.getAddress();
    connectBtn.textContent = `Connected: ${shortenAddress(userAddress)}`;

    
    loadOffers();
    setupEventListeners();
  } catch (error) {
    showError(error);
  }
});

// 2. Create Offer
async function createOffer() {
  try {
    const fromToken = document.getElementById('fromToken').value;
    const toToken = document.getElementById('toToken').value;
    const rate = document.getElementById('rate').value;

    if (!fromToken || !toToken || !rate) throw new Error("Fill all fields!");
    
    const tx = await contract.createOffer(fromToken, toToken, rate);
    await tx.wait();
    
    showSuccess("Offer created!");
    loadOffers(); // Refresh list
  } catch (error) {
    showError(error);
  }
}

// 3. Load All Offers
async function loadOffers() {
  try {
    const offers = await contract.getAllActiveOffers();
    offersList.innerHTML = ''; // Clear existing

    offers.forEach((offer, index) => {
      if (offer.active) {
        offersList.innerHTML += `
          <div class="offer">
            <p>From: ${formatAddress(offer.fromToken)}</p>
            <p>To: ${formatAddress(offer.toToken)}</p>
            <p>Rate: 1 = ${offer.exchangeRate}</p>
            <button onclick="swapTokens(${index})">Swap</button>
          </div>
        `;
      }
    });
  } catch (error) {
    showError(error);
  }
}

// 4. Swap Tokens
async function swapTokens(offerId) {
  try {
    const amount = prompt("Enter amount to swap:");
    if (!amount || isNaN(amount)) throw new Error("Invalid amount!");

    const tx = await contract.swapTokens(offerId, ethers.utils.parseUnits(amount, 18));
    await tx.wait();
    
    showSuccess("Swap successful!");
    loadOffers();
  } catch (error) {
    showError(error);
  }
}

// 5. Event Listeners
function setupEventListeners() {
  contract.on("OfferCreated", () => {
    loadOffers();
    showSuccess("New offer detected!");
  });
  contract.on("TokensSwapped", () => {
    loadOffers();
    showSuccess("Swap detected!");
  });
}
// Helper Functions
function shortenAddress(address) {
	return `${address.slice(0, 6)}...${address.slice(-4)}`;

}
function formatAddress(address) {
  return address === ethers.constants.AddressZero ? "Invalid Token" : shortenAddress(address);
}

function showError(error) {
  console.error(error);
  alert(`Error: ${error.message.split("(")[0]}`);

}

function showSuccess(message) {
	alert(`${message}`);

}

// Initial Load
if (window.ethereum) {
  window.ethereum.on('accountsChanged', () => window.location.reload());
  window.ethereum.on('chainChanged', () => window.location.reload());
}